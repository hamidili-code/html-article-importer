<?php
/**
 * Plugin Name:       HTML Importer for Elementor
 * Plugin URI:        https://github.com/hamidili-code/html-importer-for-elementor
 * Description:       Generate Elementor-based draft posts from a ZIP package. Reduces article publishing time from hours to minutes.
 * Version:           10.1.1
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Requires Plugins:  elementor
 * Author:            Ali Hamidili
 * Author URI:        https://shelow.ir
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       html-importer-for-elementor
 */

declare( strict_types=1 );

namespace HtmlImporterForElementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'HTML_IMPORTER_FOR_ELEMENTOR_VERSION', '10.1.1' );
define( 'HTML_IMPORTER_FOR_ELEMENTOR_FILE', __FILE__ );
define( 'HTML_IMPORTER_FOR_ELEMENTOR_DIR', plugin_dir_path( __FILE__ ) );
define( 'HTML_IMPORTER_FOR_ELEMENTOR_URL', plugin_dir_url( __FILE__ ) );
define( 'HTML_IMPORTER_FOR_ELEMENTOR_BASENAME', plugin_basename( __FILE__ ) );


spl_autoload_register( function ( string $class ): void {
	$prefix   = 'HtmlImporterForElementor\\';
	$base_dir = HTML_IMPORTER_FOR_ELEMENTOR_DIR;

	if ( strncmp( $prefix, $class, strlen( $prefix ) ) !== 0 ) {
		return;
	}

	$relative_class = substr( $class, strlen( $prefix ) );
	$file_map       = [
		'AdminPage'        => 'admin-page.php',
		'Parser'           => 'parser.php',
		'ImageUploader'    => 'image-uploader.php',
		'ElementorBuilder' => 'elementor-builder.php',
		'PostCreator'      => 'post-creator.php',
	];

	if ( isset( $file_map[ $relative_class ] ) ) {
		$file = $base_dir . $file_map[ $relative_class ];
		if ( file_exists( $file ) ) {
			require $file;
		}
	}
} );

/**
 * Main plugin class — singleton bootstrap.
 */
final class Plugin {

	private static ?Plugin $instance = null;

	public static function instance(): Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', [ $this, 'register_admin_menu' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
	}

	public function register_admin_menu(): void {
		add_menu_page(
			__( 'HTML to Elementor', 'html-importer-for-elementor' ),
			__( 'HTML to Elementor', 'html-importer-for-elementor' ),
			'manage_options',
			'html-importer-for-elementor',
			[ new AdminPage(), 'render' ],
			'dashicons-upload',
			30
		);
	}

	public function enqueue_admin_assets( string $hook ): void {
		if ( 'toplevel_page_html-importer-for-elementor' !== $hook ) {
			return;
		}
		wp_enqueue_style(
			'html-importer-for-elementor-admin',
			HTML_IMPORTER_FOR_ELEMENTOR_URL . 'templates/admin.css',
			[],
			HTML_IMPORTER_FOR_ELEMENTOR_VERSION
		);
	}
}

// Boot the plugin.
add_action( 'plugins_loaded', [ Plugin::class, 'instance' ] );

// Activation hook — ensure required extensions are available.
register_activation_hook( __FILE__, function (): void {
	if ( ! class_exists( 'ZipArchive' ) ) {
		deactivate_plugins( HTML_IMPORTER_FOR_ELEMENTOR_BASENAME );
		wp_die(
			esc_html__( 'HTML to Elementor Importer requires the PHP ZipArchive extension. Please contact your host.', 'html-importer-for-elementor' ),
			esc_html__( 'Plugin Activation Error', 'html-importer-for-elementor' ),
			[ 'back_link' => true ]
		);
	}
} );
